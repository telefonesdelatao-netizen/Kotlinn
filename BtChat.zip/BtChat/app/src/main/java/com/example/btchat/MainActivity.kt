package com.example.btchat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

@SuppressLint("MissingPermission") // checamos a permissão em ensureReady()
class MainActivity : AppCompatActivity(), BluetoothChatService.Listener {

    private var adapter: BluetoothAdapter? = null
    private var service: BluetoothChatService? = null

    private lateinit var statusText: TextView
    private lateinit var connectBar: android.view.View
    private lateinit var listenButton: Button
    private lateinit var connectButton: Button
    private lateinit var messagesList: ListView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var messagesAdapter: ArrayAdapter<String>

    /** O que fazer depois que as permissões/Bluetooth estiverem OK. */
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) ensureReady(pendingAction)
            else toast("Sem a permissão de Bluetooth o app não funciona.")
        }

    private val enableBluetoothLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (adapter?.isEnabled == true) ensureReady(pendingAction)
            else toast("Ligue o Bluetooth para conversar.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        connectBar = findViewById(R.id.connectBar)
        listenButton = findViewById(R.id.listenButton)
        connectButton = findViewById(R.id.connectButton)
        messagesList = findViewById(R.id.messagesList)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)

        messagesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        messagesList.adapter = messagesAdapter

        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) {
            statusText.text = "Este aparelho não tem Bluetooth."
            listenButton.isEnabled = false
            connectButton.isEnabled = false
            return
        }
        service = BluetoothChatService(adapter!!, this)

        listenButton.setOnClickListener { ensureReady { service?.startListening() } }
        connectButton.setOnClickListener { ensureReady { showPairedDevices() } }
        sendButton.setOnClickListener { sendCurrentMessage() }
        messageInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendCurrentMessage(); true } else false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        service?.stop()
    }

    // ------------------------------------------------- permissões e Bluetooth

    private fun ensureReady(action: (() -> Unit)?) {
        pendingAction = action

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            return
        }

        if (adapter?.isEnabled != true) {
            enableBluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }

        pendingAction = null
        action?.invoke()
    }

    // ---------------------------------------------------------------- UI

    private fun showPairedDevices() {
        val devices: List<BluetoothDevice> = adapter?.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Nenhum aparelho pareado")
                .setMessage(
                    "Primeiro pareie os dois celulares nas configurações de Bluetooth " +
                        "do Android. Depois volte aqui."
                )
                .setPositiveButton("Abrir configurações") { _, _ ->
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }

        val names = devices.map { "${it.name ?: "Sem nome"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Conectar a qual aparelho?")
            .setItems(names) { _, which -> service?.connect(devices[which]) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun sendCurrentMessage() {
        val text = messageInput.text.toString().trim()
        if (text.isEmpty()) return
        service?.send(text)
        messagesAdapter.add("Eu: $text")
        messageInput.text.clear()
    }

    private fun setChatEnabled(enabled: Boolean) {
        messageInput.isEnabled = enabled
        sendButton.isEnabled = enabled
        connectBar.visibility = if (enabled) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    // ------------------------------------------- BluetoothChatService.Listener

    override fun onStatus(text: String) {
        statusText.text = text
    }

    override fun onConnected(deviceName: String) {
        statusText.text = "Conectado a $deviceName"
        messagesAdapter.clear()
        setChatEnabled(true)
        messageInput.requestFocus()
    }

    override fun onMessage(text: String) {
        messagesAdapter.add("Ele: $text")
    }

    override fun onDisconnected() {
        statusText.text = "Desconectado"
        setChatEnabled(false)
    }
}
