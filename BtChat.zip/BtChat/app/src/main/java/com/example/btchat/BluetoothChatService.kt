package com.example.btchat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.UUID

/**
 * Chat por Bluetooth clássico (RFCOMM).
 *
 * Um aparelho chama [startListening] (servidor) e o outro chama [connect] (cliente).
 * Depois de conectado, os dois lados enviam e recebem texto com [send].
 * Todos os callbacks do [Listener] chegam na thread principal.
 */
@SuppressLint("MissingPermission") // a permissão é pedida na MainActivity
class BluetoothChatService(
    private val adapter: BluetoothAdapter,
    private val listener: Listener
) {

    interface Listener {
        fun onStatus(text: String)
        fun onConnected(deviceName: String)
        fun onMessage(text: String)
        fun onDisconnected()
    }

    companion object {
        // Os dois celulares precisam usar o MESMO UUID.
        val APP_UUID: UUID = UUID.fromString("8f3a1c52-6b7e-4d1a-9c2f-5e0b4a7d3c91")
        private const val SERVICE_NAME = "BtChat"
    }

    private val main = Handler(Looper.getMainLooper())

    private var acceptThread: AcceptThread? = null
    private var connectThread: ConnectThread? = null
    private var connectedThread: ConnectedThread? = null

    // ---------------------------------------------------------------- API

    @Synchronized
    fun startListening() {
        cancelAll()
        acceptThread = AcceptThread().also { it.start() }
        status("Esperando o outro aparelho conectar…")
    }

    @Synchronized
    fun connect(device: BluetoothDevice) {
        cancelAll()
        connectThread = ConnectThread(device).also { it.start() }
        status("Conectando a ${safeName(device)}…")
    }

    fun send(text: String) {
        val thread = synchronized(this) { connectedThread } ?: return
        thread.write(text)
    }

    @Synchronized
    fun stop() {
        cancelAll()
    }

    // ----------------------------------------------------------- internos

    @Synchronized
    private fun cancelAll() {
        acceptThread?.cancel(); acceptThread = null
        connectThread?.cancel(); connectThread = null
        connectedThread?.cancel(); connectedThread = null
    }

    @Synchronized
    private fun onSocketReady(socket: BluetoothSocket) {
        // Só um chat por vez: fecha o que estiver em andamento.
        acceptThread?.cancel(); acceptThread = null
        connectThread = null
        connectedThread?.cancel()

        val thread = ConnectedThread(socket)
        connectedThread = thread
        thread.start()

        val name = safeName(socket.remoteDevice)
        main.post { listener.onConnected(name) }
    }

    private fun connectionLost(thread: ConnectedThread) {
        val wasCurrent = synchronized(this) {
            if (connectedThread === thread) {
                connectedThread = null
                true
            } else false
        }
        if (wasCurrent) main.post { listener.onDisconnected() }
    }

    private fun status(text: String) = main.post { listener.onStatus(text) }

    private fun safeName(device: BluetoothDevice): String =
        try { device.name ?: device.address } catch (e: SecurityException) { device.address }

    // ------------------------------------------------------------ threads

    /** Servidor: fica esperando alguém conectar. */
    private inner class AcceptThread : Thread() {
        private var serverSocket: BluetoothServerSocket? = null
        @Volatile private var cancelled = false

        override fun run() {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, APP_UUID)
                val socket = serverSocket?.accept()   // bloqueia até alguém conectar
                if (socket != null) {
                    onSocketReady(socket)
                }
            } catch (e: IOException) {
                if (!cancelled) status("Falha ao esperar conexão: ${e.message}")
            } finally {
                try { serverSocket?.close() } catch (_: IOException) {}
            }
        }

        fun cancel() {
            cancelled = true
            try { serverSocket?.close() } catch (_: IOException) {}
        }
    }

    /** Cliente: conecta ao aparelho que está esperando. */
    private inner class ConnectThread(private val device: BluetoothDevice) : Thread() {
        private var socket: BluetoothSocket? = null
        @Volatile private var cancelled = false

        override fun run() {
            try {
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(APP_UUID)
                socket = s
                s.connect()   // bloqueia até conectar ou falhar
                onSocketReady(s)
            } catch (e: IOException) {
                try { socket?.close() } catch (_: IOException) {}
                if (!cancelled) {
                    status("Não consegui conectar. O outro aparelho tocou em “Esperar conexão”?")
                    main.post { listener.onDisconnected() }
                }
            }
        }

        fun cancel() {
            cancelled = true
            try { socket?.close() } catch (_: IOException) {}
        }
    }

    /** Lê e escreve mensagens depois de conectado. */
    private inner class ConnectedThread(private val socket: BluetoothSocket) : Thread() {
        private val input = DataInputStream(socket.inputStream)
        private val output = DataOutputStream(socket.outputStream)
        @Volatile private var cancelled = false

        override fun run() {
            try {
                while (true) {
                    val text = input.readUTF()   // uma mensagem por chamada
                    main.post { listener.onMessage(text) }
                }
            } catch (e: IOException) {
                // conexão caiu ou foi fechada
            } finally {
                try { socket.close() } catch (_: IOException) {}
                if (!cancelled) connectionLost(this)
            }
        }

        fun write(text: String) {
            try {
                synchronized(output) {
                    output.writeUTF(text)
                    output.flush()
                }
            } catch (e: IOException) {
                status("Erro ao enviar a mensagem")
            }
        }

        fun cancel() {
            cancelled = true
            try { socket.close() } catch (_: IOException) {}
        }
    }
}
