# BT Chat

App Android (Kotlin) de chat por Bluetooth: instale o mesmo app em dois celulares e eles conversam entre si, sem internet.

## Como compilar

1. Instale o **Android Studio** (precisa de um PC ou Mac).
2. `File > Open` e escolha a pasta `BtChat`.
3. Deixe o Gradle sincronizar. Se o Android Studio sugerir atualizar o plugin do Gradle, aceite.
4. Conecte o celular por USB (com "Depuração USB" ligada) e clique em **Run**.
   Para o segundo celular, repita o passo 4 com ele conectado.

Também dá para gerar o APK em `Build > Build APK(s)` e enviar o arquivo para o outro celular.

## Como usar

1. Nas configurações do Android, **pareie os dois celulares** por Bluetooth (uma vez só).
2. Abra o app nos dois.
3. No celular A, toque em **Esperar conexão**.
4. No celular B, toque em **Conectar** e escolha o celular A na lista.
5. Pronto: digite e toque em **Enviar**.

## Como funciona

- `BluetoothChatService.kt`: Bluetooth clássico (RFCOMM). Um lado abre um servidor (`AcceptThread`), o outro conecta (`ConnectThread`), e `ConnectedThread` lê e escreve mensagens (`readUTF` / `writeUTF`). Os dois apps usam o mesmo UUID.
- `MainActivity.kt`: tela, permissões (`BLUETOOTH_CONNECT` no Android 12+) e lista de aparelhos pareados.

## Limites

- Funciona com 2 aparelhos por vez.
- Só texto (até 2000 caracteres por mensagem).
- O histórico não é salvo: ao desconectar, a conversa some.
- Android apenas. iPhone não conversa com esse app.
